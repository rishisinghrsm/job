<?php include "header.php" ?>

    
    <div class="container" >
        <div class="row"  style="min-height: 80vh;display:flex;justify-content:center;align-items:center"s>
            <div class="col-md-4 p-5 bg-warning border text-capitalize fs-2 text-center"><a class="text-white " href="mainCategory.php">Main Category</a></div>
            <div class="col-md-4 p-5 bg-warning border text-capitalize fs-2 text-center"><a class="text-white " href="firstCategory.php">State Category</a></div>
            <div class="col-md-4 p-5 bg-warning border text-capitalize fs-2 text-center"><a class="text-white " href="category.php"> Sub Category</a></div>
        </div>
    </div>

