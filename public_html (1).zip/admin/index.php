<?php include 'config.php';
session_start();
if(isset($_SESSION["username"])){
    header('Location: https://bharatjobfinder.com/admin/dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | Bharat Job Findder</title>
    <link rel="stylesheet" href="bootstrap.css">
</head>
<body class="d-flex align-items-center justify-content-center" style="min-height: 100vh;background-image:url(di.svg);background-repeat:no-repeat;background-size:cover">
    
<div class="container " >
    <div class="row  ">
        <div class="col-md-4 m-auto mb-5 border p-5 shadow-lg text-white" style=" backdrop-filter: blur(10px);">
            <form action="login.php" method="post">
                <h3>Bharat Job Finder</h3>
               
                <label for="user" class="">Username</label>
                <input type="text" name="username" id="user" class="form-control">
                <br>
                <label for="Pass" class="">Password</label>
                <input type="password" name="password" id="pass" class="form-control">
                <br>
                <input type="submit" value="Login" name="submit" class="form-control">
            </form>
        </div>
    </div>
</div>
</body>
</html>