<?php include "header.php" ?>
<?php
        if($_SESSION['role'] == 0){       
     header('Location:dashboard.php');
       
       } ?>
<div class="container">
    <div class="row">
        <div class="col-md-4 m-auto">
            <form action="backgroundEditUser.php" method="post">
                <?php
                $url = $_GET['id'];
                // echo $url;
                $sql = "SELECT * FROM user where id = $url";
                // echo $sql;
                $result  = mysqli_query($conn, $sql) or die('Fail'. mysqli_error($conn));
                while ($row = mysqli_fetch_assoc($result)) {
                    // echo $row['catSNo'];
                ?>

                    <input type="text" name="editUser" id="editUser" class="form-control mb-4" value="<?php echo $row['username'] ?>" >
                    <input type="text" name="editPass" id="editPass" class="form-control mb-4" value="<?php echo hex2bin($row['password']) ?>" >
                    <label for="editRole"> 0 for Normal user And 1 For Admin</label>
                    <input type="text" name="editRole" id="editRole" class="form-control mb-4" value="<?php echo $row['role'] ?>" >
                    <input type="text" name="sno" id="sno"  value="<?php echo $row['id'] ?>" hidden>
                    <?php
                }
                
                ?>
                <!-- <input type="text" name="edit" id="edit" > -->
                <input type="submit" value="SUBMIT" name="submit">
                <!-- <a href="backgroundEditcategory.php?id=<?php echo $row['catSNo'] ?>">UPDATE</a> -->
            </form>


           
        </div>
    </div>
</div>