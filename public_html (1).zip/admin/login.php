<?php
include "config.php";


if(isset($_POST['submit'])){
    $username =mysqli_real_escape_string($conn,$_POST['username']);
    $password = bin2hex($_POST['password']);
    // $role = $_POST['role'];

    $sql = "SELECT id,username,role,post FROM user WHERE username = '{$username}' AND password = '{$password}'";
    $result= mysqli_query($conn,$sql) or die("Query Fail");

    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            session_start();
            $_SESSION["username"] = $row['username'];
            $_SESSION["id"] = $row['id'];
            $_SESSION["post"] = $row['post'];
            $_SESSION["role"] = $row['role'];
            // echo $host;
            header("Location: https://bharatjobfinder.com/admin/dashboard.php");
        }
    }else{
        echo "No User Found";
    }
}else{
    echo "Login Fail";
}


?>