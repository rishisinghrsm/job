<?php
include "config.php";
if(isset($_POST['submit'])){

    $user = $_POST['user'];
    $pass = bin2hex($_POST['pass']);
    $role = $_POST['role'];

    $addSql = "INSERT INTO user (username,password,role) values('{$user}','{$pass}',{$role})";
    $addresult = mysqli_multi_query($conn,$addSql) or die('add user query fail');
     header('Location:user.php?added=1');
}else{
    echo "error in add user";
}
?>