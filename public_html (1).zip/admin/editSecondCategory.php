<?php include "header.php" ?>

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <form action="backgroundEditSecondCategory.php" method="post">
                <?php
                $url = $_GET['id'];
                // echo $url;
                $sql = "SELECT * FROM secondCategory where id = $url";
                // echo $sql;
                $result  = mysqli_query($conn, $sql) or die('Fail'. mysqli_error($conn));
                while ($row = mysqli_fetch_assoc($result)) {
                ?>

                    <input type="text" name="sno" id="sno"  value="<?php echo $row['id'] ?>" hidden>
                    
                    <input type="text" name="edit" id="edit"  value="<?php echo $row['secondCategory'] ?>" >
                    <input type="text" name="editShort" id="edit"  value="<?php echo $row['secondCategoryShort'] ?>" >
                    <?php
                }
                
                ?>
                <input type="submit" value="SUBMIT" name="submit">
            </form>


            
        </div>
    </div>
</div>