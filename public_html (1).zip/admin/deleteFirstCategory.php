<?php
include 'header.php';

// if(isset($_POST['submit'])){
               
                
                 $url = $_GET['id'];

                $sql = "DELETE FROM `firstCategory` WHERE id = $url";
                $result = mysqli_query($conn,$sql) or die('Fail To Delete');
                    header('Location:firstCategory.php?isDeleted=1');
            // }else{
            //     echo "fail". mysqli_error($conn);
            // }
             
             ?>