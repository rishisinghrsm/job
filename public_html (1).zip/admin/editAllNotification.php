<?php include "header.php" ?>

<?php
if ($_SESSION['role'] == 0) {
    header('Location:dashboard.php');
} ?>

<body>






    <div class="container mt-5">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="col-md-12">
                <table border cellspacing="20px" cellpadding="20px" class="w-100">
                    <thead style="border: 3px solid black;">
                        <tr>
                            <th>Sno</th>
                            <th>Image</th>
                            <th>Post Title</th>
                            <th>Show</th>
                            <th>Admit </th>
                            <th>Result</th>
                            <th>By</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include "config.php";
                        // $id = $_GET['id'];

                        $sql = "SELECT * FROM notification LEFT JOIN user ON notification.by = user.id ORDER BY sNo DESC";
                        $result = mysqli_query($conn, $sql) or die('Query Fail For Category');
                        while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                            <tr style="border: 1px solid black;">
                                <td><?php echo $row['sNo'] ?></td>
                                <td><img src='<?php echo $row['img'] ?>' width="40px"></td>
                                <td><?php echo substr($row['title'], 0, 55) . "...."; ?></td>
                                <td><a href="showPostForUpdate.php?id=<?php echo $row['sNo'] ?>">Show Post</a></td>
                                <td><?php if ($row['admit'] == 1) {
                                        echo "<i class='bi bi-check-circle-fill text-success fs-2'></i>";
                                    } else {
                                        echo '<i class="bi bi-check-circle-fill text-danger fs-2"></i>';
                                    } ?></td>
                                <td><?php if ($row['result']) {
                                        echo "<i class='bi bi-check-circle-fill text-success fs-2'></i>";
                                    } else {
                                        echo '<i class="bi bi-check-circle-fill text-danger fs-2"></i>';
                                    } ?></td>
                                <td><?php echo $row['username'] ?></td>

                                <td><a href="deleteAllPost.php?id=<?php echo $row['sNo'] ?>&userId=<?php echo $row['id'] ?>" onclick="return confirm('Are you sure?')" class="btn btn-outline-danger">Delete</a></td>
                                <td><a href="editPost.php?id=<?php echo $row['sNo'] ?>" onclick="return confirm('Are you sure?')" class="btn btn-outline-success">Update</a></td>
                            </tr>
                        <?php };
                        if (isset($_GET['approved']) && $_GET['approved'] == '1') {
                            echo '

                    
                    ';
                        }
                        if (isset($_GET['added']) && $_GET['added'] == '1') {
                            echo '
                        <div class="d-flex justify-content-center">
                        <div class="alert alert-success w-75" role="alert">
                            Category is been Added.
                        </div>
                    </div>
                            ';
                        }
                        ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>
    <script language="JavaScript" type="text/javascript">
        function checkDelete() {
            return confirm('Are you sure?');
        }
    </script>
</body>

</html>