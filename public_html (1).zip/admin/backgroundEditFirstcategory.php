<?php
include "header.php";

if(isset($_POST['submit'])){
                 $edit  = $_POST['edit'];
                 $sno  = $_POST['sno'];
                //  $url = $_GET['id']; 

                //  $editCategory  = $_POST['editcategory'];
                //  $no  = $row['catSNo'];
               
                    $updateSql = "UPDATE `firstCategory` SET `firstCategory` = '{$edit}' where `id` = $sno";
                    echo $updateSql;
                    $updateResult = mysqli_query($conn,$updateSql) or die("update fail");
                    header('Location:firstCategory.php');
            }else{
                echo "fail". mysqli_error($conn);
            }
             
             ?>