<?php
include 'header.php';

// if(isset($_POST['submit'])){
                 $url = $_GET['id'];

                //  $editCategory  = $_POST['editcategory'];
                //  $no  = $row['catSNo'];
                echo $edit;
                echo $url;
                    $updateSql = "DELETE FROM `user` WHERE id = $url";
                    $updateResult = mysqli_query($conn,$updateSql) or die("update fail");
                    header('Location: user.php?isDeleted=1');
            // }else{
            //     echo "fail". mysqli_error($conn);
            // }
             
             ?>