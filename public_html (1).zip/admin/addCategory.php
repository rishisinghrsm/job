<?php
include "config.php";
if(isset($_POST['submit'])){

    $add = $_POST['addCategory'];

    $addSql = "INSERT INTO category (category) values('{$add}')";
    $addresult = mysqli_multi_query($conn,$addSql) or die('add Category query fail');
     header('Location:category.php?added=1');
}else{
    echo "error in add category";
}
?>