<?php
include 'header.php';

if(isset($_POST['submit'])){
                 $editUser  = $_POST['editUser'];
                 $editPass  = bin2hex($_POST['editPass']);
                 $editRole  = $_POST['editRole'];
                 $sno  = $_POST['sno'];
                 $url = $_GET['id'];

                //  $editCategory  = $_POST['editcategory'];
                //  $no  = $row['catSNo'];
                echo $edit;
                echo $url;
                    $updateSql = "UPDATE `user` SET `username` = '{$editUser}', password = '{$editPass}', role = {$editRole} where `id` = $sno";
                    $updateResult = mysqli_query($conn,$updateSql) or die("update fail");
                    header('Location:user.php?up=1');
            }else{
                echo "fail". mysqli_error($conn);
            }
             
             ?>