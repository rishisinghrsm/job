<?php
include 'header.php';

// if(isset($_POST['submit'])){
                 $url = $_GET['id'];
                 $userId = $_GET['userId'];

                $sql = "DELETE FROM `notification` WHERE sNo = $url;";
                $sql .= "UPDATE `user` SET `post`= post-1 WHERE id = $userId";
                $result = mysqli_multi_query($conn,$sql) or die('Fail To Delete');
                    header('Location:editAllNotification.php?isDeleted=1');
            // }else{
            //     echo "fail". mysqli_error($conn);
            // }
             
             ?>