<?php include 'config.php';
session_start();
if(!isset($_SESSION["username"])){
    header('Location: hhttps://bharatjobfinder.com/admin/index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bharat Job Finder</title>
    <link rel="stylesheet" href="bootstrap.css">
    <!-- UIkit CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/css/uikit.min.css" />

<!-- icon -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<!-- UIkit JS -->
<script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit-icons.min.js"></script>
<!-- <script src="script.js"></script> -->
</head>
<body>

<div class="container-fluid border shadow bg-white sticky-top mb-5">
    <div class="row d-flex justify-content-between p-3">
        <div class="col-md-3"><a href="dashboard.php">Bharat Job Finder</a></div>
        <div class="col-md-3 text-end"> <a href="logout.php" class="text-end">Hello <?php echo $_SESSION["username"] ?>, Logout</a></div>
    </div>
</div>

<?php
// echo "<a href='{$_SERVER["HTTP_REFERER"]}' class='btn btn-outline-info w-100'>Go back </a>";
// echo "<pre>";
// print_r($_SERVER);
// echo "</pre>";


?>


<!-- <br> -->
