<?php include 'header.php' ?>
<?php
        if($_SESSION['role'] == 0){       
     header('Location:dashboard.php');
       
       } ?>
<body>
    

    <div class="container">
        <div class="row border p-3">
            <div class="col-md-3 text-center">ADD NEW STATE</div>
            <div class="col-md-3">
                <form action="addSecondCategory.php" method="post">
                    <input type="text" class="w-100" name="addSecondCategory" id="addSecondCategory" placeholder="Add New SecondCategory" required>
                </div>
                <div class="col-md-3">

                    <input type="text" class="w-100" name="addSecondCategoryShort" id="addSecondCategory" placeholder="Add Second Category Short Form" required>
                </div>
                <div class="col-md-3">
                    <input type="submit"  class="w-100"  name="submit" value="SUBMIT">
                </form>
            </div>
        </div>
    </div>



    <div class="container mt-5">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="col-md-8">
                <table border cellspacing="20px" cellpadding="20px" class="w-100">
                    <thead style="border: 3px solid black;">
                        <tr>
                            <th>Sno</th>
                <th>Category Name</th>
                <th>Category Short Name</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include "config.php";
            
            
            $sql = "SELECT * FROM secondCategory";
            $result = mysqli_query($conn, $sql) or die('Query Fail For SecondCategory');
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr style="border: 1px solid black;">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['secondCategory'] ?></td>
                    <td><?php echo $row['secondCategoryShort'] ?></td>
                    <td><a href="editSecondCategory.php?id=<?php echo $row['id'] ?>">Edit</a></td>
                <td><a href="deleteSecondCategory.php?id=<?php echo $row['id'] ?>"  onclick="return confirm('Are you sure?')">Delete</a></td>
            </tr>
            <?php };
            if (isset($_GET['isDeleted']) && $_GET['isDeleted'] == '1') {
                echo '
                <div class="d-flex justify-content-center">
                <div class="alert alert-success w-75" role="alert">
                    SecondCategory is been removed.
                </div>
            </div>
                    ';


                }
                    if (isset($_GET['added']) && $_GET['added'] == '1') {
                        echo '
                        <div class="d-flex justify-content-center">
                        <div class="alert alert-success w-75" role="alert">
                            SecondCategory is been Added.
                        </div>
                    </div>
                            ';}
            ?>
        </tbody>
    </table>
    
    
    </div>
    </div>
    </div>
    <script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('Are you sure?');
}
</script>
</body>
</html>