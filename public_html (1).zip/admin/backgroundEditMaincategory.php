<?php
include 'header.php';

if(isset($_POST['submit'])){
                 $edit  = $_POST['edit'];
                 $sno  = $_POST['sno'];
                 $url = $_GET['id'];

                //  $editCategory  = $_POST['editcategory'];
                //  $no  = $row['catSNo'];
                echo $edit;
                echo $url;
                    $updateSql = "UPDATE `firstcategory` SET `firstCategory` = '{$edit}' where `id` = $sno";
                    $updateResult = mysqli_query($conn,$updateSql) or die("update fail");
                    header('Location:mainCategory.php');
            }else{
                echo "fail". mysqli_error($conn);
            }
             
             ?>