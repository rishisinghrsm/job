<?php
include 'header.php';

if(isset($_POST['submit'])){
                 $edit  = $_POST['edit'];
                 $sno  = $_POST['sno'];
                 $url = $_GET['id'];

                //  $editCategory  = $_POST['editcategory'];
                //  $no  = $row['catSNo'];
                echo $edit;
                echo $url;
                    $updateSql = "UPDATE `category` SET `category` = '{$edit}' where `catSNo` = $sno";
                    $updateResult = mysqli_query($conn,$updateSql) or die("update fail");
                    header('Location:category.php');
            }else{
                echo "fail". mysqli_error($conn);
            }
             
             ?>