<?php
include "config.php";
if(isset($_POST['submit'])){

    $add = $_POST['addSecondCategory'];
    $addShort = $_POST['addSecondCategoryShort'];

    $addSql = "INSERT INTO secondcategory (secondCategory,secondCategoryShort) values('{$add}','{$addShort}')";
    // echo $addSql;
    $addresult = mysqli_query($conn,$addSql) or die('add secondCategory query fail');
     header('Location:firstCategory.php?added=1');
}else{
    echo "error in add secondCategory";
}
?>