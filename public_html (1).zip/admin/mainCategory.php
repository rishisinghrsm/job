<?php include 'header.php' ?>
<?php
        if($_SESSION['role'] == 0){       
     header('Location:dashboard.php');
       
       } ?>
<body>
    

    <div class="container">
        <div class="row border p-3">
            <div class="col-md-4 text-center">ADD NEW CATEGORY</div>
            <div class="col-md-4">
                <form action="addMainCategory.php" method="post">
                    <input type="text" class="w-100" name="addCategory" id="addCategory" placeholder="Add New Category" required>
                </div>
                <div class="col-md-4">
                    <input type="submit"  class="w-100"  name="submit" value="SUBMIT">
                </form>
            </div>
        </div>
    </div>



    <div class="container mt-5">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="col-md-8">
                <table border cellspacing="20px" cellpadding="20px" class="w-100">
                    <thead style="border: 3px solid black;">
                        <tr>
                            <th>Sno</th>
                <th>Category name</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include "config.php";
            
            
            $sql = "SELECT * FROM firstCategory ";
            $result = mysqli_query($conn, $sql) or die('Query Fail For Category');
          
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr style="border: 1px solid black;">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['firstCategory'] ?></td>
                    <td><a href="editMainCategory.php?id=<?php echo $row['id'] ?>">Edit</a></td>
                <td><a href="deleteMainCategory.php?id=<?php echo $row['id'] ?>"  onclick="return confirm('Are you sure?')">Delete</a></td>
            </tr>
            <?php };
            if (isset($_GET['isDeleted']) && $_GET['isDeleted'] == '1') {
                echo '
                <div class="d-flex justify-content-center">
                <div class="alert alert-success w-75" role="alert">
                    Category is been removed.
                </div>
            </div>
                    ';


                }
                    if (isset($_GET['added']) && $_GET['added'] == '1') {
                        echo '
                        <div class="d-flex justify-content-center">
                        <div class="alert alert-success w-75" role="alert">
                            Category is been Added.
                        </div>
                    </div>
                            ';}
            ?>
        </tbody>
    </table>
    
    
    </div>
    </div>
    </div>
    <script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('Are you sure?');
}
</script>
</body>
</html>