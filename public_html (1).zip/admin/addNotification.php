<?php
include 'header.php';
if (isset($_POST['submit'])) {
    
    $title = $_POST['title'];
    $postDate = $_POST['postDate'];
    $lastDate = $_POST['lastDate'];
    $catId = $_POST['category'];
    $catId2 = $_POST['category2'];
    $catId3 = $_POST['category3'];
    $editor = $_POST['editor'];
    $admitCheckBox = $_POST['admitCheckBox'];
    $resultCheckBox = $_POST['resultCheckBox'];
    
    $vac = $_POST['vac'];
    $img = $_POST['img'];
  
    $sql = "INSERT INTO notification(`title`,`postDate`,`lastDate`,`catId`,`catId2`,`catId3`,`detail`,`by`,`result`,`admit`,`img`,`vacancy`)
     VALUES('{$title}','{$postDate}','{$lastDate}',{$catId},{$catId2},{$catId3},'{$editor}',{$_SESSION['id']},{$resultCheckBox},{$admitCheckBox},'{$img}','{$vac}');" ;
    $sql .= "UPDATE user SET post = post + 1 where `id` = {$_SESSION['id']}";
    
    // echo $sql;
    $result = mysqli_multi_query($conn, $sql) or die('Query Fail For Image <br><br>' . mysqli_error($conn));
    if($result){
        echo 'Inserted';
       
        header('Location:notification.php');
    }else{
        echo "Not Inserted";
    }
} else {
    echo 'Error';
}

?>