<?php
include "config.php";

$id = $_GET['id'];

$updateSql = "UPDATE `notification` SET `status` = 1 WHERE sNo = {$id}" ;
$updateResult = mysqli_query($conn,$updateSql) or die("update fail");
header('Location: approve.php?approved=1');


?>