<?php include 'header.php' ?>


    <div class="container p-5">
        <div class="row d-flex justify-content-center">
            <div class="col-md-8 fs-4">
            <?php
                               $url = $_GET['id'];
                               $sql1 = "SELECT * FROM `notification` where sNo = $url";
                               $result1 = mysqli_query($conn,$sql1) or die("Query failed in img");
                               while($row1 = mysqli_fetch_assoc($result1)){
                      
                              ?>
                               <div class="d-flex justify-content-between align-items-center " >
                                        <div class="text-success">Post Date - <?php echo date("d-m-Y ", strtotime($row1['postDate'])); ?></div>
                                        <div class="text-danger">Last Date - <?php echo date("d-m-Y ", strtotime($row1['lastDate'])); ?></div>
                                        <!-- <div>Total No. Of Vaccancy - 1200</div> -->
                                    </div>
                              
                <h2><?php echo $row1['title'] ?></h2>
               <p><?php echo $row1['detail'] ?></p> 
            </div>
            <div class="col-md-2  border">
                <div class="sticky-top pt-3">

                    <div class="d mt-5">
                        <img src="<?php echo $row1['img']; ?>" alt="<?php echo $row1['img']; ?>">
                    </div>
                    
                    <div class="mt-5 border-top fs-2">
                        <?php
                                    $currentDateTime = new DateTime('now');
                                    $currentDate = $currentDateTime->format('d-m-Y');
                                    // echo $currentDate;  
                                    $p = $currentDate;
                                    $l = $row1['lastDate'];
                                    $date1 = date("d-m-Y H:i:s", strtotime($p));
                                    
                                    $date2 = date("d-m-Y H:i:s", strtotime($l));
                                    
                                    $diff = abs(strtotime($date2) - strtotime($date1));
                                    
                                    $date =  floor($diff / 86400);
                                    if ($date <= 0) {

                                        echo "  <p class='text-center mb-0'>Days Left <br> <span style='color:red;font-size:60px'> Closed </span></p> ";
                                    } else {
                                        echo " <p class='text-center mb-0'>Days Left <br> <span style='color:green;font-size:90px'>" . $date . "</span></p>";
                                    } ?>
                </div>
                <div class="text-center border-top mt-3 pt-2">
                    <h3>Total Vaccancy</h3>
                    <h1><?php echo $row1['vacancy']; ?></h1>
                </div>
            </div>
            </div>
            <!-- <div class="col-md-2"></div> -->
            <?php } ?>
        </div>
    </div>



    <!-- <div class="container text-center">
        <div class="row ">
            <div class="col-md-12 d-flex justify-content-center">
                <table cellpadding="30px" border="1px" cellspacing="20px">
                    <thead style="border: 1px solid black;">

                        <tr>
                            <th style="border: 1px solid black; font-weight: 700;">Total Number's Of Seat</th>
                            <th style="border: 1px solid black; font-weight: 700;"> SC / ST</th>
                            <th style="border: 1px solid black; font-weight: 700;">OBC</th>
                            <th style="border: 1px solid black; font-weight: 700;">GEN</th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td style="border: 1px solid black; font-weight: 700;">1200</td>
                            <td style="border: 1px solid black; font-weight: 700;">500</td>
                            <td style="border: 1px solid black; font-weight: 700;">500</td>
                            <td style="border: 1px solid black; font-weight: 700;">200</td>
                        </tr>
                    </tbody>
                    </table>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12 border-danger border mt-5 rounded-3 p-2 text-danger">
                <h2>Important Date</h2>
            </div>
            <div class="col-md-12 mt-3 fs-5">
                <ul>
                  <li>Application Begin : 27/09/2023</li>
                  <li>Last Date for Apply Online : 26/10/2023 upto 03 PM</li>
                  <li>Last Date Complete Form : 26/10/2023</li>
                 
                </ul>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 border-danger border mt-5 rounded-3 p-2 text-danger">
                <h2>Requirement</h2>
            </div>
            <div class="col-md-12 mt-3 fs-5">
                <ul>
                  <li>Matric with 75% marks with science</li>
                  <li>Only Unmarried Male Candidates Are Eligible</li>
                  <li>Passed / Appearing Engineering Degree in Related Trade / Branch</li>
                  <li>Final Year Appearing Candidate are also Eligible</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 border-danger border mt-5 rounded-3 p-2 text-danger">
                <h2>Age Requirement</h2>
            </div>
            <div class="col-md-12 mt-3 fs-5">
              <ul>
                <li>Minimum Age : 20 Years</li>
                <li>Maximum Age : 27 Years</li>
                <li>Age Limit Calculate as on 01/07/2024</li>
                <li>Age Relaxation Extra as per Recruitment Rules.</li>
              </ul>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 border-danger border mt-5 rounded-3 p-2 text-danger">
                <h2>Application Fee</h2>
            </div>
            <div class="col-md-12 mt-3 fs-5">
              <ul>
                <li>General / OBC : 0/-</li>
                <li>SC / ST : 0/-</li>
                <li>No Application Fee for the Army TGT 139 Exam 2023-24 All Category Candidates Only Applied the Online Form</li>
               
              </ul>
            </div>
        </div>
    </div>


    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 border text-center fs-3 p-3 text-danger">Apply From Here - - - - ></div>
            <div class="col-md-6 border text-center fs-3 p-3 text-danger"> Click Here</div>
        </div>
    </div> -->


    <br><br>
    <br>
</body>
</html>