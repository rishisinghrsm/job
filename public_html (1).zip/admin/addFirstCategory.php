<?php
include "config.php";
if(isset($_POST['submit'])){

    $add = $_POST['addFirstCategory'];

    $addSql = "INSERT INTO firstCategory (firstCategory) values('{$add}')";
    // echo $addSql;
    $addresult = mysqli_query($conn,$addSql) or die('add firstCategory query fail');
     header('Location:firstCategory.php?added=1');
}else{
    echo "error in add firstCategory";
}
?>