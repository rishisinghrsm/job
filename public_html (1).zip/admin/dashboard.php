<?php include "header.php" ?>

<div class="container m-auto mt-4">
    <?php
    if ($_SESSION['role'] == 0) {
    ?>
        <p class="p-2 bg-light ">

            Your Total No Of Post Is : - <?php echo $_SESSION['post'];
                                        } ?>
        </p>
        <div class="row">
            <div class="col-md-5 shadow-lg  m-auto p-5 fs-3 bg-danger text-center"><a class="text-white w-auto " href="notification.php">Add post</a></div>
            <div class="col-md-5 shadow-lg m-auto  p-5 fs-3 bg-info text-center"><a class="text-white w-auto   " href="editNotification.php?id=<?php echo $_SESSION["id"] ?>">Edit post</a></div>
        </div>
        <br>
        <div class="row d-flex m-auto align-items-center justify-content-evenly">

            <?php
            if ($_SESSION['role'] == 1) {
            ?>
                <div class="col-md-3 shadow-lg p-3 bg-transparent  text-center" style="border:5px solid #0d6efd ">Total  Post <br>
                    <h1 class="fw-bolder text-info" style="font-size: 100px;">

                        <?php
                        $sql = "SELECT * FROM notification";
                        $result = mysqli_query($conn, $sql) or die('Query Fail For Category');
                        $totalActivePost = 0;
                        while ($row = mysqli_fetch_assoc($result)) {
                            $totalActivePost++;
                        ?>
                        <?php } ?>
                        <?php echo $totalActivePost ?>
                    </h1>
                </div>
                <div class="col-md-3 shadow-lg p-3  bg-transparent  text-center" style="border:5px solid #ffc107">Total Active Post <br>
                    <h1 class="fw-bolder text-warning" style="font-size: 100px;">

                        <?php
                        $sql = "SELECT * FROM notification WHERE status = 1";
                        $result = mysqli_query($conn, $sql) or die('Query Fail For Category');
                        $totalActivePost = 0;
                        while ($row = mysqli_fetch_assoc($result)) {
                            $totalActivePost++;
                        ?>
                        <?php } ?>
                        <?php echo $totalActivePost ?>
                    </h1>
                </div>
                <div class="col-md-3 shadow-lg p-3 bg-transparent  text-center" style="border:5px solid #dc3545">Total inactive Post <br>
                    <h1 class="fw-bolder text-danger" style="font-size: 100px;">

                        <?php
                        $sql = "SELECT * FROM notification WHERE status = 0";
                        $result = mysqli_query($conn, $sql) or die('Query Fail For Category');
                        $totalActivePost = 0;
                        while ($row = mysqli_fetch_assoc($result)) {
                            $totalActivePost++;
                        ?>
                        <?php } ?>
                        <?php echo $totalActivePost ?>
                    </h1>
                </div>
                <br>
        </div>
        <br>
        <div class="row">
            <div class="col-md-3 p-5 fs-4 bg-secondary text-center"><a class="text-white w-auto   " href="editAllNotification.php">All post</a></div>
            <div class="col-md-3 p-5 fs-4 bg-success text-center"><a class="text-white w-auto    " href="categoryDetail.php">Add Category</a></div>
            <div class="col-md-3 p-5 fs-4 bg-warning text-center"><a class="text-white w-auto    " href="approve.php">Approval</a></div>
            <div class="col-md-3 p-5 fs-4 bg-primary text-center"><a class="text-white w-auto    " href="user.php">User</a></div>
        <?php } ?>
        <!-- <div class="col-md-3 p-4 bg-danger text-center"><a class="text-white w-auto " href="">User</a></div> -->
        </div>
</div>