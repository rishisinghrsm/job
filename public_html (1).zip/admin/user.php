<?php include 'header.php' ?>
<?php
        if($_SESSION['role'] == 0){       
     header('Location:dashboard.php');
       
       } ?>
<body>


    <div class="container-fluid">
        <h2>ADD NEW USER</h2>
        <div class="row border p-3">
            <!-- <div class="col-md-2 text-center">ADD NEW USER</div> -->
            <div class="col-md-3">
                    <form action="addUser.php" method="post">
                    <input type="text" class="w-100" name="user" id="user" placeholder="Add New User" required>
                </div>

                <div class="col-md-3">

                    <input type="text" class="w-100" name="pass" id="pass" placeholder="User's Password" required>
                </div>

                <div class="col-md-3">
                    <select name="role" id="role" class="w-100">
                        <option value="0">NORMAL</option>
                        <option value="1">ADMIN</option>
                    </select>
                    <!-- <input type="text" class="w-100" name="role" id="role" placeholder="User's Role" required> -->
                </div>

                <div class="col-md-3">
                    <input type="submit" class="w-100" name="submit" value="SUBMIT">
                </div>
                
            </form>
        </div>
    </div>
    </div>



    <div class="container mt-5">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="col-md-8">
                <table border cellspacing="20px" cellpadding="20px" class="w-100">
                    <thead style="border: 3px solid black;">
                        <tr>
                            <th>Sno</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Role</th>
                            <th>No Of Post</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include "config.php";


                        $sql = "SELECT * FROM user ";
                        $result = mysqli_query($conn, $sql) or die('Query Fail For Category');
                        while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                            <tr style="border: 1px solid black;">
                                <td><?php echo $row['id'] ?></td>
                                <td><?php echo $row[ 'username'] ?></td>
                                <td><?php echo hex2bin($row['password']) ?></td>
                                <td><?php
                                    if ($row['role'] == 0) {
                                        echo "<span class='text-info'>NORMAL</span>";
                                    } else if($row['role'] == 1){
                                        echo "<span class='text-success'>ADMIN</span>";
                                    }else{
                                        echo "<span class='text-danger'>WRONG</span>";
                                    }
                                    ?></td>
                                    <td><?php echo $row[ 'post'] ?></td>
                                <td><a href="editUser.php?id=<?php echo $row['id'] ?>">Edit</a></td>
                                <td><a href="deleteUser.php?id=<?php echo $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a></td>
                            </tr>
                        <?php };
                        if (isset($_GET['isDeleted']) && $_GET['isDeleted'] == '1') {
                            echo '
                <div class="d-flex justify-content-center">
                <div class="alert alert-success w-75" role="alert">
                    User is been removed.
                </div>
            </div>
                    ';
                        }
                        if (isset($_GET['added']) && $_GET['added'] == '1') {
                            echo '
                        <div class="d-flex justify-content-center">
                        <div class="alert alert-success w-75" role="alert">
                            User is been Added.
                        </div>
                    </div>
                            ';
                        }
                        ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>
    <script language="JavaScript" type="text/javascript">
        function checkDelete() {
            return confirm('Are you sure?');
        }
    </script>
</body>

</html>