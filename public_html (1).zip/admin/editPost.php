<?php include 'header.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.css">
    <!-- <script src="https://cdn.ckeditor.com/ckeditor5/40.0.0/classic/ckeditor.js"></script> -->
    <!-- <script src="https://cdn.ckeditor.com/4.23.0-lts/standard/ckeditor.js"></script> -->
    <script src="ckeditor/ckeditor.js"></script>
    <style>
        .ck-editor__editable[role="textbox"] {
            /* editing area */
            min-height: 500px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-10 m-auto">
                <?php
               
                $url = $_GET['id'];
                $sql = "SELECT * FROM notification 
                        LEFT JOIN firstCategory ON notification.catId  = firstCategory.id
                        LEFT JOIN secondCategory ON notification.catId2 = secondCategory.id
                        LEFT JOIN category ON notification.catId3 = category.catSNo
                         WHERE notification.sNo = $url";
                $result = mysqli_query($conn, $sql) or die('Query Fail For Category');
                while ($row = mysqli_fetch_assoc($result)) {
                ?>
                    <form action="updateNotification.php" method="post" class="form">
                        <div class="">


                            <label for="result">Result</label>

                            <select name="resultCheckBox" id="result">

                                <option value="<?php echo $row['result'] ?>" selected ><?php if ($row['result']  == 1) {
                                                                                                    echo 'Yes';
                                                                                                } else {
                                                                                                    echo 'No';
                                                                                                } ?></option>
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>

                            <label for="admit">Admit</label>

                            <select name="admitCheckBox" id="admit">

                                <option value="<?php echo $row['admit'] ?>" selected ><?php if ($row['admit']  == 1) {
                                                                                                    echo 'Yes';
                                                                                                } else {
                                                                                                    echo 'No';
                                                                                                } ?></option>
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $row['sNo'] ?>">
                        <input type="text" name="title" id="title" required class="form-control mt-5 mb-5" value="<?php echo $row['title'] ?>" placeholder="Post Title">
                        <textarea name="editor" id="editor" rows="10" cols="30" required class="form-control mt-5 "><?php echo $row['detail'] ?></textarea>
                        <img src="<?php echo $row['img'] ?>" alt="<?php echo $row['img'] ?>" width="150px" height="150px" border='1px'>
                        <input type="text" name="img" id="img" required class="form-control mt-5 mb-5" placeholder="Post img" value="<?php echo $row['img'] ?>">
                        <input type="text" name="vac" id="vac" required class="form-control mt-5 mb-5" placeholder="Total No. Of Vacancy" value="<?php echo $row['vacancy'] ?>">
                        <div class="d-flex justify-content-evenly">
                            <div class="">

                                <label for="postDate" class="mt-5">Starting Date</label>
                                <input type="date" name="postDate" id="postDate" value="<?php echo $row['postDate'] ?>" class="form-control">
                            </div>
                            <div class="">

                                <label for="lastDate" class="mt-5">Last Date</label>
                                <input type="datetime-local" name="lastDate" id="lastDate" value="<?php echo $row['lastDate'] ?>" class="form-control ">
                            </div>
                        </div>
                        <select name="category" id="category" class="form-control mt-5">
                            <!-- <option value="0" selected>Select Job Type</option> -->
                            <?php
                            include "config.php";
                            // $url = $_GET['id'];
                            $sqlForCategory = "SELECT * FROM firstCategory  ";
                            $resultForCategory = mysqli_query($conn, $sqlForCategory) or die('Query Fail For Category');
                            // $rowForCategory =  mysqli_fetch_assoc($resultForCategory);
                            while ($rowForCategory = mysqli_fetch_assoc($resultForCategory)) {
                                if ($row['catId'] == $rowForCategory['id']) {

                                    $selected = "selected";
                                } else {
                                    $selected = "";
                                }
                                ?>
                                <option <?php echo $selected ?> value="<?php echo $rowForCategory['id'] ?>"><?php echo $rowForCategory['firstCategory'] ?></option>
                            <?php }; ?>
                        </select>
                        <!-- second job type category -->
                        <select name="category2" id="category2" class="form-control mt-5">
                            <option value="0">Select State</option>
                            <?php
                            include "config.php";
                            $sqlForCategory2 = "SELECT * FROM secondCategory";
                            $resultForCategory2 = mysqli_query($conn, $sqlForCategory2) or die('Query Fail For Category');
                            // $rowForCategory =  mysqli_fetch_assoc($resultForCategory);


                            while ($rowForCategory2 = mysqli_fetch_assoc($resultForCategory2)) {

                                if ($row['catId2'] == $rowForCategory2['id']) {

                                    $selected = "selected";
                                } else {
                                    $selected = "";
                                    echo "no";
                                }
                                echo $row['catId2'];
                                echo $rowForCategory2['id'];
                            ?>
                                <option <?php echo $selected ?> value="<?php echo $rowForCategory2['id'] ?>"><?php echo $rowForCategory2['secondCategory'] ?></option>
                            <?php }; ?>
                        </select>
                        <!-- third job type category -->

                        <select name="category3" id="category3" class="form-control mt-5">
                            <option value="0" selected>Select job Category</option>
                            <?php
                            include "config.php";


                            $sqlForCategory = "SELECT * FROM category";
                            $resultForCategory = mysqli_query($conn, $sqlForCategory) or die('Query Fail For Category');
                            $rowForCategory =  mysqli_fetch_assoc($resultForCategory);

                           
                            while ($rowForCategory = mysqli_fetch_assoc($resultForCategory)) {
                          
                                if ($row['catId3'] == $rowForCategory['catSNo']) {

                                    $selected = "selected";
                                } else {
                                    $selected = "";
                                }
                                ?>
                                <option <?php echo $selected ?> value="<?php echo $rowForCategory['catSNo'] ?>"><?php echo $rowForCategory['category'] ?></option>
                            <?php }; ?>
                        </select>
                        <input type="submit" name='submit' value="SUBMT" class="form-control mt-5">
                    </form>

                <?php }; ?>



            </div>
        </div>
    </div>




















    <script>
        CKEDITOR.replace('editor');
    </script>
</body>


</html>