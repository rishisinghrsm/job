<?php
include 'header.php';

// if(isset($_POST['submit'])){
                 $edit  = $_POST['edit'];
                 $sno  = $_POST['sno'];
                 $url = $_GET['id'];

                $sql = "DELETE FROM `firstcategory` WHERE id = $url";
                $result = mysqli_query($conn,$sql) or die('Fail To Delete');
                    header('Location:mainCategory.php?isDeleted=1');
            // }else{
            //     echo "fail". mysqli_error($conn);
            // }
             
             ?>