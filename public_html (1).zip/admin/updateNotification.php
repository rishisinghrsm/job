<?php
include 'header.php';
if (isset($_POST['submit'])) {
    
    $title = $_POST['title'];
    $postDate = $_POST['postDate'];
    $lastDate = $_POST['lastDate'];
    $catId = $_POST['category'];
    $catId2 = $_POST['category2'];
    $catId3 = $_POST['category3'];
    $editor = $_POST['editor'];
    $category = $_POST['category'];
    $category2 = $_POST['category2'];
    $category3 = $_POST['category3'];
    $admitCheckBox = $_POST['admitCheckBox'];
    $resultCheckBox = $_POST['resultCheckBox'];
    $id = $_POST['id'];
    $vac = $_POST['vac'];
    $img = $_POST['img'];
    include "config.php";
    $date = date("Y-m-d");
echo date("Y-m-d");
  
    $sql =" UPDATE `notification` SET `title`='{$title}',`postDate`='{$postDate}',`lastDate`='{$lastDate}',`catId`='{$category}',`catId2`='{$category2}',`catId3`='{$category3}',`detail`='{$editor}',`result`='{$resultCheckBox}',`admit`='{$admitCheckBox}',`img`='{$img}',`vacancy`='{$vac}',`updateDate` = '$date' WHERE sNo = $id";
    
    // echo $sql;
    $result = mysqli_multi_query($conn, $sql) or die('Query Fail For Image <br><br>' . mysqli_error($conn));
    if($result){
        echo 'Inserted';
       
        header('Location:dashboard.php');
    }else{
        echo "Not Inserted";
    }
} else {
    echo 'Error';
}

?>