<?php include 'header.php' ?>
<?php
if ($_SESSION['role'] == 0) {
    header('Location:dashboard.php');
} ?>

<body>






    <div class="container mt-5">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="col-md-12">
                <table border cellspacing="20px" cellpadding="20px" class="w-100">
                    <thead style="border: 3px solid black;">
                        <tr>
                            <th>Sno</th>
                            <th>Image</th>
                            <th>Post Title</th>
                            <th>Show</th>
                            <th>Result</th>
                            <th>Admit</th>
                            <th>By</th>
                            <th>Approve</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include "config.php";


                        $sql = "SELECT * FROM notification LEFT JOIN user ON notification.by = user.id  WHERE status = 0 ORDER BY sNo DESC";
                        $result = mysqli_query($conn, $sql) or die('Query Fail For Category');
                        while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                            <tr style="border: 1px solid black;">
                                <td><?php echo $row['sNo'] ?></td>
                                <td style="max-width: 80px;overflow:hidden"><img src='<?php echo $row['img'] ?>' width="60px"></td>
                                <td><?php echo substr($row['title'], 0, 55) . "...."; ?></td>
                                <td class=""><a href="showPost.php?id=<?php echo $row['sNo'] ?>">Show Post</a></td>
                                <td><?php if ($row['result']) {
                                        echo "<i class='bi bi-check-circle-fill text-success fs-1'></i>";
                                    } else {
                                        echo '<i class="bi bi-x-circle-fill text-danger fs-1"></i>';
                                    } ?></td>
                                <td><?php if ($row['admit']) {
                                        echo "<i class='bi bi-check-circle-fill text-success fs-1'></i>";
                                    } else {
                                        echo '<i class="bi bi-x-circle-fill text-danger fs-1"></i>';
                                    } ?></td>
                                <td><?php echo $row['username'] ?></td>

                                <td><a href="approvePost.php?id=<?php echo $row['sNo'] ?>" onclick="return confirm('Are you sure?')" class="btn btn-outline-success">Approve</a></td>
                            </tr>
                        <?php };
                        if (isset($_GET['approved']) && $_GET['approved'] == '1') {
                            echo '';
                        }
                        if (isset($_GET['added']) && $_GET['added'] == '1') {
                            echo '
                        <div class="d-flex justify-content-center">
                        <div class="alert alert-success w-75" role="alert">
                            Category is been Added.
                        </div>
                    </div>
                            ';
                        }
                        ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>
    <script language="JavaScript" type="text/javascript">
        function checkDelete() {
            return confirm('Are you sure?');
        }
    </script>
</body>

</html>