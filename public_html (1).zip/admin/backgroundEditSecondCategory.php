<?php
include "header.php";

if(isset($_POST['submit'])){
                 $edit  = $_POST['edit'];
                 $editShort  = $_POST['editShort'];
                 $sno  = $_POST['sno'];
                //  $url = $_GET['id']; 

                //  $editCategory  = $_POST['editcategory'];
                //  $no  = $row['catSNo'];
               
                    $updateSql = "UPDATE `secondCategory` SET `secondCategory` = '{$edit}' , secondCategoryShort = '{$editShort}' where `id` = $sno";
                    echo $updateSql;
                    $updateResult = mysqli_query($conn,$updateSql) or die("update fail");
                    header('Location:firstCategory.php');
            }else{
                echo "fail". mysqli_error($conn);
            }
             
             ?>