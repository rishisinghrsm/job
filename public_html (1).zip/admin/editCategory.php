<?php include "header.php" ?>

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <form action="backgroundEditcategory.php" method="post">
                <?php
                $url = $_GET['id'];
                // echo $url;
                $sql = "SELECT * FROM category where catSNo = $url";
                // echo $sql;
                $result  = mysqli_query($conn, $sql) or die('Fail'. mysqli_error($conn));
                while ($row = mysqli_fetch_assoc($result)) {
                ?>

                    <input type="text" name="sno" id="sno"  value="<?php echo $row['catSNo'] ?>" hidden>
                    <input type="text" name="edit" id="edit"  value="<?php echo $row['category'] ?>" >
                    <?php
                }
                
                ?>
                <input type="submit" value="SUBMIT" name="submit">
            </form>


           
        </div>
    </div>
</div>